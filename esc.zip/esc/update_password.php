<?php  
include('koneksi.php');

$id_karyawan	= $_POST['id_karyawan'];
$password		= $_POST['password'];

$query = mysql_query("UPDATE users SET password = '$password' WHERE id_karyawan='$id_karyawan'") or die(mysql_error());

if ($query) {
	echo "<script>
		alert('PASSWORD BERHASIL DIUBAH');
		window.location='index.php';
		</script>";
}else{
echo "<script>
		alert('GAGAL MENYIMPAN DATA');
		window.location='index.php';
		</script>";
}
?>