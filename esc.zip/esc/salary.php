<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->

<div class="row">
   <div class="col-md-12">
      <!-- TABLE: LATEST ORDERS -->
      <div class="box box-info">
         <div class="box-header with-border">
            <h3 class="box-title">List Salary per Customer</h3>
            <div class="box-tools pull-right">
               <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
               <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
         </div>
         <!-- /.box-header -->
         <div class="box-body">
            <div class="table-responsive">
               <a class="btn btn-warning" data-target=".add-import" data-toggle="modal"><i class="fa fa-download"></i> Import</a> 
               <table id="example1" class="table table-bordered table-striped table-hover table-responsive">
                  <thead>
                     <tr>
                        <th>
                           NO.
                        </th>
                        <th>
                           Nama Customers
                        </th>
                        <th width="220">
                           ACTION
                        </th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                        include('koneksi.php');
                        $query = mysql_query("SELECT DISTINCT customer.id_customer, customer.customer FROM slip_gaji 
                          inner join customer on slip_gaji.id_customer=customer.id_customer
                          ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
                        
                        if(mysql_num_rows($query) == 0){ 
                          
                          echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
                          
                        }else{  
                          $no = 1; 
                          $sum=0;
                          while($data = mysql_fetch_assoc($query)){ ?>
                     <tr>
                        <td>
                           <?php echo $no; ?>
                        </td>
                        <td>
                           <?php echo $data['customer']; ?>
                        </td>
                        <td>
                           <a class="btn btn-primary" href="salary_karyawan.php?id_customer=<?php echo $data['id_customer']; ?>">View</a>
                        </td>
                     </tr>
                     <?php $no++;  } } 
                        ?>
                  </tbody>
               </table>
            </div>
            <!-- /.table-responsive -->
         </div>
         <!-- /.box-body -->
         <div class="box-footer clearfix">
         </div>
         <!-- /.box-footer -->
      </div>
      <!-- /.box -->
   </div>
   <!-- /.col -->
</div>
<!-- /.col -->
</div><!-- /.row -->
<div class="example-modal">
   <div class="modal modal-default add-import">
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">×</span></button>
               <h4 class="modal-title">Tambah Data Customer</h4>
            </div>
            <div class="modal-body">
               <form class="form-control" name="myForm" id="myForm" onSubmit="return validateForm()" action="small.php" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                     <label class="col-sm-4 control-label">Nama Customer</label>
                     <div class="col-sm-8">
                        <select name="id_customer" class="form-control" required>
                           <option value="" disabled="" selected="" style="display:none" ;="">Pilih</option>
                           <?php
                              $query = mysql_query("SELECT * FROM customer ORDER BY customer ASC") or die(mysql_error());
                              
                              if(mysql_num_rows($query) == 0){ 
                              
                               echo '<option value="">Tidak ada data!</option>';
                              
                              }else{  
                              
                              while($data = mysql_fetch_assoc($query)){ ?>
                           <option value="<?php echo $data['id_customer']; ?>"><?php echo $data['customer']; ?></option>
                           <?php }} ?>
                        </select>
                     </div>
                  </div>
                  
                  <br>
                  <div class="form-group">
                     <label class="col-sm-4 control-label">Periode Pengajian</label>
                     <div class="col-sm-8">
                        <input type="text" name="periode" class="form-control" data-provide="datepicker" id="date" placeholder="Month Year">
                     </div>
                  </div>
                  <div class="form-group">
                     <label class="col-sm-4 control-label">Upload Excel</label>
                     <div class="col-sm-8">
                        <input type="file" id="filepegawaiall" name="filepegawaiall" class="form-control" required />
                        <br>
                        <p>File Harus Berekstensi .xls (97-2003).</p>
                     </div>
                  </div>
            </div>
            <div class="modal-footer">
            <button type="reset" class="btn btn-danger pull-left">Reset</button>
            <button type="submit" name="submit" class="btn btn-primary">Save</button>
            </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
</div>
</div>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
   $(function() {
     $( "#date" ).datepicker({
       altField: "#date",
       altFormat: "MM yy",
       changeMonth: true,
       changeYear: true
     });
     
   });
</script>
<script type="text/javascript">
   //    validasi form (hanya file .xls yang diijinkan)
       function validateForm()
       {
           function hasExtension(inputID, exts) {
               var fileName = document.getElementById(inputID).value;
               return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
           }
   
           if(!hasExtension('filepegawaiall', ['.xls'])){
               alert("Hanya file XLS (Excel 2003) yang diijinkan.");
               return false;
           }
       }
</script>
<script>
   $(function () {
     $("#example1").DataTable();
     $('#example2').DataTable({
       "paging": true,
       "lengthChange": true,
       "searching": true,
       "ordering": true,
       "info": false,
       "autoWidth": false
     });
   });
</script>
<?php include_once("design/footer.php");?>