<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
      <!-- Small boxes (Stat box) -->
      <div class="row">
<div class="row col-md-12">
<div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">Change Password</h3>
      <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div><!-- /.box-header -->
            <?php 
													$id = $_GET['id_karyawan'];

													$query = mysql_query("
												        SELECT *
												        FROM users
												        where id_karyawan='$id'");
													
													$data = mysql_fetch_array($query);
													
													?>
       
            <form method="POST" action="update_password.php" name="fupload">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Password Lama</label>

                  <div class="col-sm-10">
                  <input type="hidden" name="id_karyawan" value="<?php echo $id; ?>" >
                    <input type="text" class="form-control" name="customer" value="<?php echo $data['password']; ?>" required>
                  </div>
                </div>
                <br>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Password Baru</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="password" minlength="4" maxlength="20" required>
                  </div>
                </div>
               
                
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <a href="index.php"><button class="btn btn-default">Cancel</button></a>
                <button type="submit" class="btn btn-info pull-right">Simpan</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div><!-- /.box -->
        </div><!-- /.col -->
   
    </div><!-- /.col -->
</div><!-- /.row -->
<?php include_once("design/footer.php");?>