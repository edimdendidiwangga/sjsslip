<?php include_once("koneksi.php");?>
<?php


header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=user_password.xls");
?>
<?php
$id = $_POST['id_customer'];
?>

<table class="table table-bordered table-striped table-hover table-responsive" id="customer">
  <thead>
    <tr>
      <th>
        NO.
      </th>
      <th>
        Customer
      </th>
      <th>
        Area
      </th>
      <th>
        NIK
      </th>
      <th>
       Nama Users
      </th>
      <th>
       Password
      </th>
      <th>
       Level
      </th>
      
    </tr>
  </thead>
  <tbody>
  <?php
    include('koneksi.php');
    $query = mysql_query("SELECT * FROM users inner join karyawan on users.id_karyawan=karyawan.id_karyawan inner join customer on karyawan.id_customer=customer.id_customer where karyawan.id_customer='$id' ORDER BY id_users ASC") or die(mysql_error());
    
    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{  
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
    <tr>
      <td>
        <?php echo $no; ?>
      </td>
      <td>
        <?php echo $data['customer'] ?>
      </td>
      <td>
        <?php echo $data['area'] ?>
      </td>
      <td>
        <?php echo $data['nik'] ?>
      </td>
      <td>
        <?php echo $data['nama_karyawan'] ?>
      </td>
      <td>
        <?php echo $data['password'] ?>
      </td>
      <td>
        <?php if($data['level']='1'){echo 'Karyawan';}
          elseif($data['level']='2'){echo 'Finance';}?>
      </td>
      
    </tr>
    <?php $no++; } } ?>
 
    
  </tbody>
</table>