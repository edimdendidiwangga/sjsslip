<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->
<div class="row">
    <div class="col-md-12">
  <!-- TABLE: LATEST ORDERS -->
  <div class="box box-info">
    <div class="box-header with-border">
    <?php
    $id = $_GET['id_customer'];
      $query = mysql_query("SELECT * FROM customer where id_customer='$id'") or die(mysql_error());
      $d = mysql_fetch_assoc($query);
      ?>

      <h3 class="box-title">Slip Gaji Terbaru <?php echo strtoupper($d['customer'])?></h3>
      <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div><!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
        <table class="table table-striped table-bordered table-responsive" id="example" >
          <thead>
            <tr>
              <th>No</th>
              <th>Tanggal Pembayaran</th>
              <th>Periode Salary</th>
             
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php
     $query = mysql_query("SELECT DISTINCT periode_gaji, tgl, id_customer FROM slip_gaji where id_customer='$id'
                 
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    
    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{ 
    
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
          <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data['tgl']; ?></td>
              <td><?php echo $data['periode_gaji']; ?></td>
              <td><a href="customer_salary.php?id_customer=<?php echo $data['id_customer'];?>&&periode_gaji=<?php echo $data['periode_gaji'];?>" class="btn btn-success">View</a> | <a href="delete-slip.php?tgl=<?php echo $data['tgl'];?>&id_customer=<?php echo $data['id_customer'];?>" onclick="return confirm('Jika dihapus, data slip gaji pada periode yang dipilih akan terhapus semua. Yakin Anda Ingin Menghapus Data ini ?')" class="btn btn-danger">Delete</a>
            </tr>
           <?php $no++; }}?>
          </tbody>
        </table>
      </div><!-- /.table-responsive -->
    </div><!-- /.box-body -->
    <div class="box-footer clearfix">
     
    </div><!-- /.box-footer -->
  </div><!-- /.box -->
</div><!-- /.col -->
   
    </div><!-- /.col -->
</div><!-- /.row -->
<script>
$(document).ready(function(){
    $('#example').DataTable();
});
</script>
<?php include_once("design/footer.php");?>