<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
      <!-- Small boxes (Stat box) -->
      <div class="row">
       
         <div class="col-md-12">
         <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Daftar Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <button class="btn btn-primary" data-target=".add-slide" data-toggle="modal">Tambah</button>
            <button class="btn btn-success" data-target=".export" data-toggle="modal">Export Excel</button>
   <table class="table table-bordered table-striped table-hover table-responsive" id="customer">
  <thead>
    <tr>
      <th>
        NO.
      </th>
      <th>
        Customer
      </th>
      <th>
        NIK
      </th>

      <th>
       Nama Users
      </th>
      <th>
       Password
      </th>
      <th>
       Level
      </th>
      <th width="150">
        ACTION
      </th>
    </tr>
  </thead>
  <tbody>
  <?php
    
    include('koneksi.php');
    $query = mysql_query("SELECT * FROM users inner join karyawan on users.id_karyawan=karyawan.id_karyawan inner join customer on karyawan.id_customer=customer.id_customer ORDER BY id_users ASC") or die(mysql_error());
    
    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{  
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
    <tr>
      <td>
        <?php echo $no; ?>
      </td>
      <td>
        <?php echo $data['customer'] ?>
      </td>
      <td>
        <?php echo $data['nik'] ?>
      </td>
      <td>
        <?php echo $data['nama_karyawan'] ?>
      </td>
      <td>
        <?php echo $data['password'] ?>
      </td>
      <td>
        <?php if($data['level']='1'){echo 'Karyawan';}
          elseif($data['level']='2'){echo 'Finance';}?>
      </td>
      <td>
          <a href="delete-users.php?id_users=<?php echo $data['id_users'];?>" onclick="return confirm('Yakin Anda Ingin Menghapus Data ini ?')" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php $no++; } } ?>
 
    
  </tbody>
</table>
</div>
</div>



<div class="example-modal">
        <div class="modal modal-default add-slide">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Tambah Data Users</h4>
              </div>
              <div class="modal-body">
                <p>


                  <div class="box box-info">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" action="add-users.php" class="form-horizontal" >
              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-4 control-label">Nama Users</label>

                  <div class="col-sm-8">
                    <input type="text" class="form-control" name="name" required>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-4 control-label">Username</label>

                  <div class="col-sm-8">
                    <input type="email" class="form-control" name="email" required>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-4 control-label">Password</label>

                  <div class="col-sm-8">
                    <input type="password" class="form-control" name="password" required>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-4 control-label">Level</label>

                  <div class="col-sm-8">
                    <select name="level" class="form-control" required="">
                    <option value="admin">Admin</option>
                    <option value="operator">Karyawan</option>
                    </select>
                  </div>
                </div>
                
                
              </div>
              <!-- /.box-body -->
              
              <!-- /.box-footer -->
            
          </div>

                </p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
              </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->



        <div class="example-modal">
        <div class="modal modal-default export">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Export Data Users</h4>
              </div>
              <div class="modal-body">
                <p>


                  <div class="box box-info">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" action="export-users.php" class="form-horizontal" >
              <div class="box-body">
                <div class="form-group">
                     <label class="col-sm-4 control-label">Nama Customer</label>
                     <div class="col-sm-8">
                        <select name="id_customer" class="form-control" required>
                           <option value="" disabled="" selected="" style="display:none" ;="">Pilih</option>
                           <?php
                              $query = mysql_query("SELECT * FROM customer ORDER BY customer ASC") or die(mysql_error());
                              
                              if(mysql_num_rows($query) == 0){ 
                              
                               echo '<option value="">Tidak ada data!</option>';
                              
                              }else{  
                              
                              while($data = mysql_fetch_assoc($query)){ ?>
                           <option value="<?php echo $data['id_customer']; ?>"><?php echo $data['customer']; ?></option>
                           <?php }} ?>
                        </select>
                     </div>
                  </div>
                
                
              </div>
              <!-- /.box-body -->
              
              <!-- /.box-footer -->
            
          </div>

                </p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Export</button>
              </div>
              </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
      </div>
      <script>
$(document).ready(function(){
    $('#customer ').DataTable();
});
</script>
<?php include_once("design/footer.php");?>           