<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->
<div class="row">
    <div class="col-md-12">
  <!-- TABLE: LATEST ORDERS -->
  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">Summary Salary Terbaru</h3>
      <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div><!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
        <table class="table table-striped table-bordered table-responsive" id="example" >
          <thead>
            <tr>
              <th>No</th>
              <th>Periode Salary</th>
              <th>Total salary</th>
              
            </tr>
          </thead>
          <tbody>
          <?php
  $query = mysql_query("SELECT * FROM salary  ORDER BY id_salary desc limit 1") or die(mysql_error());


    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{ 
    
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){  
        
        ?>
          <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data['periode_gaji']; ?></td>
              <td>Rp. <?php echo number_format($data['total_thp']); ?></td>
              
            </tr>
           <?php $no++; }} ?>
          </tbody>
        </table>
      </div><!-- /.table-responsive -->
    </div><!-- /.box-body -->
    <div class="box-footer clearfix">
     
    </div><!-- /.box-footer -->
  </div><!-- /.box -->
</div><!-- /.col -->
   
    </div><!-- /.col -->
</div><!-- /.row -->

<?php include_once("design/footer.php");?>