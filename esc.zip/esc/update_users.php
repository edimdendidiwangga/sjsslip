<?php
include('koneksi.php');

$id				= $_POST['id'];
$name			= $_POST['name'];
$email			= $_POST['email'];
$password		= $_POST['password'];
$level			= $_POST['level'];

$query = mysql_query("UPDATE users SET name = '$name', email = '$email', password = '$password', level = '$level' WHERE id='$id'") or die(mysql_error());

if ($query) {
	echo "<script>
		alert('DATA BERHASIL DITAMBAHKAN');
		window.location='users.php';
		</script>";
}else{
echo "<script>
		alert('GAGAL MENYIMPAN DATA');
		window.location='users.php';
		</script>";
}

?>