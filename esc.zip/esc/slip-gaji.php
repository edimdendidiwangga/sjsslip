
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->


<div class="row">
    <div class="col-md-12">
  <!-- TABLE: LATEST ORDERS -->
  <div class="pad margin no-print">
      <div class="callout callout-info" style="margin-bottom: 0!important;">
         <div class="row no-print">
        <div class="col-xs-12">


          <button type="button" class="btn btn-success pull-left" onclick="printDiv('printableArea')"><i class="fa fa-print"></i> Print</button>
         
          <button id="cmd" type="button" class="btn btn-warning pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Save PDF
          </button>
        </div>
      </div>
      </div>
    </div>
   <section class="invoice" id="printableArea">


  
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12 page-header">
       
          <div class="col-sm-10"><img src="assets/dist/img/logo_sjs.jpg" class="img-responsive" width="100"></div><div class="col-sm-2">

          <h5 class="pull-right">Date: 2/10/2014</h5>
        
      </div>
      <!-- /.col -->
      
    </div>
    <!-- info row -->
    <h2 align="center"><b>SLIP GAJI</b></h2>
    <div class="alert alert-info>">
    <div class="row invoice-info">
      <div class="col-sm-6 invoice-col">
       
        <table class="table bg-warning table-sm cf">
            <tr>
              <th style="width:40%">NAMA</th>
              
              <td>: Edim </td>
            </tr>
            <tr>
              <th>JABATAN</th>
              <td>: IT </td>
            </tr>
            <tr>
              <th>AREA / LOKASI</th>
              
              <td>: IT </td>
            </tr>
             <tr>
              <th>STATUS</th>
              
              <td>: IT </td>
            </tr>
            <tr>
              <th>NIK</th>
              
              <td>: 12345</td>
            </tr>
             <tr>
              <th>PERIODE</th>
              
              <td>: 12345</td>
            </tr>
            </table>
      </div>
      <!-- /.col -->
      
      
      <!-- /.col -->
      <div class="col-sm-6 invoice-col">
         <table class="table bg-warning cf">
            <tr>
              <th style="width:50%">No.</th>
              
              <td>: Edim </td>
            </tr>
            <tr>
              <th>PERUSAHAAN</th>
              
              <td>: IT </td>
            </tr>
            <tr>
              <th>NO. HP</th>
              
              <td>: IT </td>
            </tr>
             
            </table>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
    </div>
    

    <!-- Table row -->
     <div class="col-sm-6 invoice-col">
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Pendapatan </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-hover table-responsive">
            <tr>
              <th style="width:40%">Gaji Pokok</th>
              <td>: Rp. </td>
              <td align="right">3.000.000 </td>
            </tr>
            <tr>
              <th>Insentive 1</th>
              <td>: Rp. </td>
              <td align="right">500.000 </td>
            </tr>
            <tr>
              <th>Tunjangan 1</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr>
              <th>Tunjangan 2</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr>
              <th>Tunjangan 3</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr class="bg-info">
              <th>Grand Total Salary</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
          </table>
            </div>
          </div>
          </div>
        
        <div class="col-sm-6 invoice-col">
        <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Potongan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-hover table-responsive">
            <tr>
              <th style="width:50%">PPH 21</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr>
              <th>BPJS (1%)</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr>
              <th>Jamsostek (JHT 2%)</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr>
              <th>Potongan Lain</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            <tr class="bg-danger">
              <th>Total Potongan</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
            
          </table>
            </div>
          </div>
          </div>
    
    
      <!-- /.col -->
     <div class="row">
      <!-- accepted payments column -->
      
      <!-- /.col -->
     <div class="col-md-12">
      <div class="col-sm-6 invoice-col">
        <p class="lead"></p>

        <div class="table-responsive">
          <table class="table table-responsive">
            <tr class="bg-primary">
              <th style="width:50%">Salary Yang Diterima</th>
              <td>: Rp. </td>
              <td align="right">0 </td>
            </tr>
          </table>
        </div>
      </div>
      
      <!-- /.col -->
      </div>
    </div>
    <br>

  
      
      <!-- /.col -->
      
    </div>

    <p class="block" align="center"><i>PT SJS menyatakan cetakan ini sah sebagai bukti pembayaran yang sah.</p>
      <p class="block" align="center">Rincian Slip Pembayaran ini Dapat diakses di http://e-employee.sinarjernihsuksesindo.co.id</p>
      <p class="block" align="center">Untuk Informasi dapat menghubungi 021 - 8306679</i></p>
    <!-- /.row -->

  </section>
    </div><!-- /.col -->
</div><!-- /.row -->
<script type="text/javascript">
  function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>
<?php include_once("design/footer.php");?>