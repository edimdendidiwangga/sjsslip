<?php 
session_start();

//jika session username belum dibuat, atau session username kosong
if (!isset($_SESSION['nik']) || empty($_SESSION['nik'])) {
	//redirect ke halaman login
	header('location:login.php');
}
?>