<?php include_once("koneksi.php");?> 
<?php
   
   //memanggil file excel_reader
   require "excel_reader.php";
   
   //jika tombol import ditekan
   if(isset($_POST['submit'])){
   
       $id_customer = $_POST['id_customer'];
       
       $periode_gaji = $_POST['periode'];
       $tgl = date("d-m-Y");

       $kr = "select kategori from customer where id_customer='$id_customer'";
    $cat = mysql_query($kr);
    $cat_row = mysql_fetch_array($cat);
    $kategori = $cat_row['kategori'];
     
       $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
       $count = mb_strlen($chars);
   
       function randomPassword() {
       $alphabet = "abcdefghijkmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
       $pass = array(); //remember to declare $pass as an array
       $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
           for ($i = 0; $i < 8; $i++) {
               $n = rand(0, $alphaLength);
               $pass[] = $alphabet[$n];
           }
          return implode($pass); //turn the array into a string
        }
   
       $target = basename($_FILES['filepegawaiall']['name']) ;
       move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
       
       chmod($_FILES['filepegawaiall']['name'],0777);
       $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
       
   //    menghitung jumlah baris file xls
       $baris = $data->rowcount($sheet_index=0);
        
        if($kategori==1){
   //    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
       for ($i=2; $i<=$baris; $i++)
       { 
   //    membaca data (kolom ke-1 sd terakhir)
         $nik            = $data->val($i, 1, 0);
         $nama_karyawan  = addslashes($data->val($i, 2, 0));
         $jabatan        = addslashes($data->val($i, 3, 0));
         $status         = $data->val($i, 4, 0);
         $area           = $data->val($i, 5, 0);
         $gaji_pokok     = $data->val($i, 6, 0);
         $adjustment     = $data->val($i, 7, 0);
         $service_charge = $data->val($i, 8, 0);
         $tunjangan_lain = $data->val($i, 9, 0);
         $total_pendapatan  = $data->val($i, 10, 0);
         $pph21             = $data->val($i, 11, 0);
         $jamsostek         = $data->val($i, 12, 0);
         $bpjs              = $data->val($i, 13, 0);
         $pensiun           = $data->val($i, 14, 0);
         $potongan_lain     = $data->val($i, 15, 0);
         $total_potongan    = $data->val($i, 16, 0);
         $salary            = $data->val($i, 17, 0);
   
        $password = randomPassword();
        
   //      setelah data dibaca, masukkan ke tabel pegawai sql
        $sql = "select * from karyawan where nik='$nik'";
       $check = mysql_query($sql);
       $checkrows=mysql_num_rows($check);
   
   
       if($checkrows>0) {
         $query = mysql_query("insert into small_income (id_small_income, service_charge) 
        values('', '$service_charge')") or die(mysql_error());

         $sql = "select max(id_small_income) as last_id_small_income from small_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_small_income = $row['last_id_small_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_small_income', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());
    
    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
    //simpan data ke database
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
    $sql = "select id_karyawan, nik from karyawan where nik='$nik'";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['id_karyawan'];
   
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());    
      } else {
           
    $query = "INSERT into karyawan (id_karyawan, id_customer, nik, nama_karyawan, jabatan, status, area) 
           values('', '$id_customer', '$nik', '$nama_karyawan', '$jabatan', '$status', '$area')";
           $hasil = mysql_query($query);
   
       $query = mysql_query("insert into small_income (id_small_income, service_charge) 
        values('', '$service_charge')") or die(mysql_error());

         $sql = "select max(id_small_income) as last_id_small_income from small_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_small_income = $row['last_id_small_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_small_income', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());
   
    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_karyawan) as last_id_karyawan from karyawan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['last_id_karyawan'];
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());
   
   $query = mysql_query("insert into users (id_users, id_karyawan, password, level) 
     values('', '$last_id_karyawan', '$password', '1')") or die(mysql_error());
    
   }
   }

 }else if($kategori==2){

        for ($i=2; $i<=$baris; $i++)
       { 
   //    membaca data (kolom ke-1 sd terakhir)
         $nik            = $data->val($i, 1, 0);
         $nama_karyawan  = addslashes($data->val($i, 2, 0));
         $jabatan        = addslashes($data->val($i, 3, 0));
         $status         = $data->val($i, 4, 0);
         $area           = $data->val($i, 5, 0);
         $gaji_pokok     = $data->val($i, 6, 0);
         $rapel          = $data->val($i, 7, 0);
         $kehadiran      = $data->val($i, 8, 0);
         $lembur         = $data->val($i, 9, 0);
         $adjustment     = $data->val($i, 10, 0);
         $tunjangan_lain = $data->val($i, 11, 0); 
         $total_pendapatan  = $data->val($i, 12, 0);
         $pph21             = $data->val($i, 13, 0);
         $jamsostek         = $data->val($i, 14, 0);
         $bpjs              = $data->val($i, 15, 0);
         $pensiun           = $data->val($i, 16, 0);
         $tidak_hadir       = $data->val($i, 17, 0);
         $potongan_lain     = $data->val($i, 18, 0);
         $total_potongan    = $data->val($i, 19, 0);
         $salary            = $data->val($i, 20, 0);
   
        $password = randomPassword();
        
   //      setelah data dibaca, masukkan ke tabel pegawai sql
        $sql = "select * from karyawan where nik='$nik'";
       $check = mysql_query($sql);
       $checkrows=mysql_num_rows($check);

       if($checkrows>0) {

        $query = mysql_query("insert into medium_income (id_medium_income, rapel, kehadiran, lembur) 
        values('', '$rapel', '$kehadiran', '$lembur')") or die(mysql_error());

       $sql = "select max(id_medium_income) as last_id_medium_income from medium_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_income = $row['last_id_medium_income'];

        $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_medium_income', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());

   $query = mysql_query("insert into medium_piece (id_medium_piece, tidak_hadir) 
        values('', '$tidak_hadir')") or die(mysql_error());

       $sql = "select max(id_medium_piece) as last_id_medium_piece from medium_piece limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_piece = $row['last_id_medium_piece'];

    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '$last_id_medium_piece', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
    //simpan data ke database
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
    $sql = "select id_karyawan, nik from karyawan where nik='$nik'";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['id_karyawan'];
   
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());    
      } else {
           
    $query = "INSERT into karyawan (id_karyawan, id_customer, nik, nama_karyawan, jabatan, status, area) 
           values('', '$id_customer', '$nik', '$nama_karyawan', '$jabatan', '$status', '$area')";
           $hasil = mysql_query($query);
   
    $query = mysql_query("insert into medium_income (id_medium_income, rapel, kehadiran, lembur) 
        values('', '$rapel', '$kehadiran', '$lembur')") or die(mysql_error());

       $sql = "select max(id_medium_income) as last_id_medium_income from medium_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_income = $row['last_id_medium_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_medium_income', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());

   $query = mysql_query("insert into medium_piece (id_medium_piece, tidak_hadir) 
        values('', '$tidak_hadir')") or die(mysql_error());

       $sql = "select max(id_medium_piece) as last_id_medium_piece from medium_piece limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_piece = $row['last_id_medium_piece'];

    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '$last_id_medium_piece', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_karyawan) as last_id_karyawan from karyawan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['last_id_karyawan'];
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());
   
   $query = mysql_query("insert into users (id_users, id_karyawan, password, level) 
     values('', '$last_id_karyawan', '$password', '1')") or die(mysql_error());
    
   }
   }
  }if($kategori==3){
   //    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
       for ($i=2; $i<=$baris; $i++)
       { 
   //    membaca data (kolom ke-1 sd terakhir)
         $nik            = $data->val($i, 1, 0);
         $nama_karyawan  = addslashes($data->val($i, 2, 0));
         $jabatan        = addslashes($data->val($i, 3, 0));
         $status         = $data->val($i, 4, 0);
         $area           = $data->val($i, 5, 0);
         $gaji_pokok     = $data->val($i, 6, 0);
         $adjustment     = $data->val($i, 7, 0);
         $rapel          = $data->val($i, 8, 0);
         $overtime       = $data->val($i, 9, 0);
         $shift          = $data->val($i, 10, 0);
         $kehadiran      = $data->val($i, 11, 0);
         $insentive      = $data->val($i, 12, 0);
         $tunjangan_lain    = $data->val($i, 13, 0);
         $total_pendapatan  = $data->val($i, 14, 0);
         $pph21             = $data->val($i, 15, 0);
         $jamsostek         = $data->val($i, 16, 0);
         $bpjs              = $data->val($i, 17, 0);
         $pensiun           = $data->val($i, 18, 0);
         $potongan_lain     = $data->val($i, 19, 0);
         $total_potongan    = $data->val($i, 20, 0);
         $salary            = $data->val($i, 21, 0);
   
        $password = randomPassword();
        
   //      setelah data dibaca, masukkan ke tabel pegawai sql
        $sql = "select * from karyawan where nik='$nik'";
       $check = mysql_query($sql);
       $checkrows=mysql_num_rows($check);
   
       if($checkrows>0) {
         $query = mysql_query("insert into large_income (id_large_income, rapel, overtime, shift, kehadiran, insentive) 
        values('', '$rapel', '$overtime', '$shift', '$kehadiran', '$insentive')") or die(mysql_error());

         $sql = "select max(id_large_income) as last_id_large_income from large_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_large_income = $row['last_id_large_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_large_income', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());
    
    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
    //simpan data ke database
   
    $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
    $sql = "select id_karyawan, nik from karyawan where nik='$nik'";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['id_karyawan'];
   
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());    
      } else {
           
    $query = "INSERT into karyawan (id_karyawan, id_customer, nik, nama_karyawan, jabatan, status, area) 
           values('', '$id_customer', '$nik', '$nama_karyawan', '$jabatan', '$status', '$area')";
           $hasil = mysql_query($query);
   
       $query = mysql_query("insert into large_income (id_large_income, rapel, overtime, shift, kehadiran, insentive) 
        values('', '$rapel', '$overtime', '$shift', '$kehadiran', '$insentive')") or die(mysql_error());

         $sql = "select max(id_large_income) as last_id_large_income from large_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_large_income = $row['last_id_large_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_large_income', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());
   
    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_karyawan) as last_id_karyawan from karyawan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['last_id_karyawan'];
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());
   
   $query = mysql_query("insert into users (id_users, id_karyawan, password, level) 
     values('', '$last_id_karyawan', '$password', '1')") or die(mysql_error());
    
   }
   }

 }else if($kategori==4){
   //    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
       for ($i=2; $i<=$baris; $i++)
       { 
   //    membaca data (kolom ke-1 sd terakhir)
         $nik            = $data->val($i, 1, 0);
         $nama_karyawan  = addslashes($data->val($i, 2, 0));
         $jabatan        = addslashes($data->val($i, 3, 0));
         $status         = $data->val($i, 4, 0);
         $area           = $data->val($i, 5, 0);
         $gaji_pokok     = $data->val($i, 6, 0);
         $adjustment     = $data->val($i, 7, 0);
         $service_charge = $data->val($i, 8, 0);
         $tunjangan_lain = $data->val($i, 9, 0);
         $total_pendapatan  = $data->val($i, 10, 0);
         $pph21             = $data->val($i, 11, 0);
         $jamsostek         = $data->val($i, 12, 0);
         $bpjs              = $data->val($i, 13, 0);
         $pensiun           = $data->val($i, 14, 0);
         $potongan_lain     = $data->val($i, 15, 0);
         $total_potongan    = $data->val($i, 16, 0);
         $salary            = $data->val($i, 17, 0);
         $pph21_f             = $data->val($i, 18, 0);
         $jamsostek_f         = $data->val($i, 19, 0);
         $bpjs_f              = $data->val($i, 20, 0);
         $pensiun_f           = $data->val($i, 21, 0);
         $total_fasilitas     = $data->val($i, 22, 0);
   
        $password = randomPassword();     
   //      setelah data dibaca, masukkan ke tabel pegawai sql
        $sql = "select * from karyawan where nik='$nik'";
       $check = mysql_query($sql);
       $checkrows=mysql_num_rows($check);
   
       if($checkrows>0) {
        $query = mysql_query("insert into fasilitas (id_fasilitas, pph21_f, jamsostek_f, bpjs_f, pensiun_f, total_fasilitas) 
        values('', '$pph21_f', '$jamsostek_f', '$bpjs_f', '$pensiun_f', '$total_fasilitas')") or die(mysql_error());

       $sql = "select max(id_fasilitas) as last_id_fasilitas from fasilitas limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_fasilitas = $row['last_id_fasilitas'];

         $query = mysql_query("insert into small_income (id_small_income, service_charge) 
        values('', '$service_charge')") or die(mysql_error());

         $sql = "select max(id_small_income) as last_id_small_income from small_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_small_income = $row['last_id_small_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, id_fasilitas, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_small_income', '$last_id_fasilitas', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());
    
    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
    //simpan data ke database
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
    $sql = "select id_karyawan, nik from karyawan where nik='$nik'";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['id_karyawan'];
   
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());    
      } else {
           
    $query = "INSERT into karyawan (id_karyawan, id_customer, nik, nama_karyawan, jabatan, status, area) 
           values('', '$id_customer', '$nik', '$nama_karyawan', '$jabatan', '$status', '$area')";
           $hasil = mysql_query($query);
   
        $query = mysql_query("insert into fasilitas (id_fasilitas, pph21_f, jamsostek_f, bpjs_f, pensiun_f, total_fasilitas) 
        values('', '$pph21_f', '$jamsostek_f', '$bpjs_f', '$pensiun_f', '$total_fasilitas')") or die(mysql_error());

       $sql = "select max(id_fasilitas) as last_id_fasilitas from fasilitas limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_fasilitas = $row['last_id_fasilitas'];

         $query = mysql_query("insert into small_income (id_small_income, service_charge) 
        values('', '$service_charge')") or die(mysql_error());

         $sql = "select max(id_small_income) as last_id_small_income from small_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_small_income = $row['last_id_small_income'];

         $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, id_fasilitas, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_small_income', '$last_id_fasilitas', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());
   
    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_karyawan) as last_id_karyawan from karyawan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['last_id_karyawan'];
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());
   
   $query = mysql_query("insert into users (id_users, id_karyawan, password, level) 
     values('', '$last_id_karyawan', '$password', '1')") or die(mysql_error());
    
   }
   }

 }else if($kategori==5){

        for ($i=2; $i<=$baris; $i++)
       { 
   //    membaca data (kolom ke-1 sd terakhir)
         $nik            = $data->val($i, 1, 0);
         $nama_karyawan  = addslashes($data->val($i, 2, 0));
         $jabatan        = addslashes($data->val($i, 3, 0));
         $status         = $data->val($i, 4, 0);
         $area           = $data->val($i, 5, 0);
         $gaji_pokok     = $data->val($i, 6, 0);
         $rapel          = $data->val($i, 7, 0);
         $kehadiran      = $data->val($i, 8, 0);
         $lembur         = $data->val($i, 9, 0);
         $adjustment     = $data->val($i, 10, 0);
         $tunjangan_lain = $data->val($i, 11, 0); 
         $total_pendapatan  = $data->val($i, 12, 0);
         $pph21             = $data->val($i, 13, 0);
         $jamsostek         = $data->val($i, 14, 0);
         $bpjs              = $data->val($i, 15, 0);
         $pensiun           = $data->val($i, 16, 0);
         $tidak_hadir       = $data->val($i, 17, 0);
         $potongan_lain     = $data->val($i, 18, 0);
         $total_potongan    = $data->val($i, 19, 0);
         $salary            = $data->val($i, 20, 0);
         $pph21_f             = $data->val($i, 21, 0);
         $jamsostek_f         = $data->val($i, 22, 0);
         $bpjs_f              = $data->val($i, 23, 0);
         $pensiun_f           = $data->val($i, 24, 0);
         $total_fasilitas     = $data->val($i, 25, 0);
   
        $password = randomPassword();
        
   //      setelah data dibaca, masukkan ke tabel pegawai sql
        $sql = "select * from karyawan where nik='$nik'";
       $check = mysql_query($sql);
       $checkrows=mysql_num_rows($check);

       if($checkrows>0) {
        $query = mysql_query("insert into fasilitas (id_fasilitas, pph21_f, jamsostek_f, bpjs_f, pensiun_f, total_fasilitas) 
        values('', '$pph21_f', '$jamsostek_f', '$bpjs_f', '$pensiun_f', '$total_fasilitas')") or die(mysql_error());

       $sql = "select max(id_fasilitas) as last_id_fasilitas from fasilitas limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_fasilitas = $row['last_id_fasilitas'];

        $query = mysql_query("insert into medium_income (id_medium_income, rapel, kehadiran, lembur) 
        values('', '$rapel', '$kehadiran', '$lembur')") or die(mysql_error());

       $sql = "select max(id_medium_income) as last_id_medium_income from medium_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_income = $row['last_id_medium_income'];

        $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, id_fasilitas, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_medium_income', '$last_id_fasilitas', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());

   $query = mysql_query("insert into medium_piece (id_medium_piece, tidak_hadir) 
        values('', '$tidak_hadir')") or die(mysql_error());

       $sql = "select max(id_medium_piece) as last_id_medium_piece from medium_piece limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_piece = $row['last_id_medium_piece'];

    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '$last_id_medium_piece', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
    //simpan data ke database
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
    $sql = "select id_karyawan, nik from karyawan where nik='$nik'";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['id_karyawan'];
   
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());  

     $query = mysql_query("insert into fasilitas (id_fasilitas, pph21, jamsostek, bpjs, pensiun, total_fasilitas) 
     values('', '$pph21_f', '$jamsostek_f', '$bpjs_f', '$pensiun_f', '$total_fasilitas' )") or die(mysql_error());    
      } else {
           
    $query = "INSERT into karyawan (id_karyawan, id_customer, nik, nama_karyawan, jabatan, status, area) 
           values('', '$id_customer', '$nik', '$nama_karyawan', '$jabatan', '$status', '$area')";
           $hasil = mysql_query($query);
   
    $query = mysql_query("insert into fasilitas (id_fasilitas, pph21_f, jamsostek_f, bpjs_f, pensiun_f, total_fasilitas) 
        values('', '$pph21_f', '$jamsostek_f', '$bpjs_f', '$pensiun_f', '$total_fasilitas')") or die(mysql_error());

       $sql = "select max(id_fasilitas) as last_id_fasilitas from fasilitas limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_fasilitas = $row['last_id_fasilitas'];

        $query = mysql_query("insert into medium_income (id_medium_income, rapel, kehadiran, lembur) 
        values('', '$rapel', '$kehadiran', '$lembur')") or die(mysql_error());

       $sql = "select max(id_medium_income) as last_id_medium_income from medium_income limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_income = $row['last_id_medium_income'];

        $query = mysql_query("insert into pendapatan (id_pendapatan, id_kategori, id_fasilitas, gaji_pokok, adjustment, tunjangan_lain, total_pendapatan) 
        values('', '$last_id_medium_income', '$last_id_fasilitas', '$gaji_pokok', '$adjustment', '$tunjangan_lain', '$total_pendapatan')") or die(mysql_error());

   $query = mysql_query("insert into medium_piece (id_medium_piece, tidak_hadir) 
        values('', '$tidak_hadir')") or die(mysql_error());

       $sql = "select max(id_medium_piece) as last_id_medium_piece from medium_piece limit 1";
      $hasil = mysql_query($sql);
      $row = mysql_fetch_array($hasil);
      $last_id_medium_piece = $row['last_id_medium_piece'];

    $query = mysql_query("insert into potongan (id_potongan, id_kategori, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
     values('', '$last_id_medium_piece', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());
   
   $sql = "select max(id_karyawan) as last_id_karyawan from karyawan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_karyawan = $row['last_id_karyawan'];
   
   $sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_pendapatan = $row['last_id_pendapatan'];
   
   
   $sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
    $last_id_potongan = $row['last_id_potongan'];
    
   $query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
     values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());


   $query = mysql_query("insert into users (id_users, id_karyawan, password, level) 
     values('', '$last_id_karyawan', '$password', '1')") or die(mysql_error());
    
   }
   }
      }
   
   $sql = "select SUM(salary) AS value_sum from slip_gaji where periode_gaji='$periode_gaji'";
    $hasil = mysql_query($sql);
    $row = mysql_fetch_array($hasil);
   $tot = $row['value_sum'];
         
         $query = "INSERT into salary (id_salary, id_customer, periode_gaji, total_thp) 
           values('', '$id_customer', '$periode_gaji', '$tot')";
           $hasil = mysql_query($query);
   
       if(!$hasil){
   //          jika import gagal
             die(mysql_error());
         }else{
   //          jika impor berhasil
             echo "<script>
       alert('DATA BERHASIL di IMPORT!');
       window.location='salary.php';
       </script>";
       }
       
   //    hapus file xls yang udah dibaca
       unlink($_FILES['filepegawaiall']['name']);
   }
   
   ?>