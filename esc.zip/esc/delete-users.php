<?php 
include('koneksi.php');

$id = $_GET['id_users'];

$query = mysql_query("delete from users where id_users='$id'") or die(mysql_error());

if ($query) {
	header('location:users.php?message=delete');
}
?>