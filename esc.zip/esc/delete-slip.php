<?php 
include('koneksi.php');

$tgl = $_GET['tgl'];
$id_customer = $_GET['id_customer'];
$query = mysql_query("delete from slip_gaji where tgl='$tgl' && id_customer='$id_customer'") or die(mysql_error());

if ($query) {
	header('location:salary_karyawan.php?id_customer=$id_customer');
}
?>