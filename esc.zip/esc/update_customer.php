<?php
include('koneksi.php');

$id				= $_POST['id_customer'];
$customer		= $_POST['customer'];
$kategori		= $_POST['kategori'];

$query = mysql_query("UPDATE customer SET customer = '$customer', kategori = '$kategori' WHERE id_customer='$id'") or die(mysql_error());

if ($query) {
	echo "<script>
		alert('DATA BERHASIL DITAMBAHKAN');
		window.location='customer.php';
		</script>";
}else{
echo "<script>
		alert('GAGAL MENYIMPAN DATA');
		window.location='customer.php';
		</script>";
}

?>