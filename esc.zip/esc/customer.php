<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->
<div class="row">
         <div class="col-md-12">
         <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Daftar Customers</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <button class="btn btn-primary" data-target=".add-slide" data-toggle="modal">Tambah</button>
   <table id="customer" class="table table-bordered table-striped table-hover table-responsive">
  <thead>
    <tr>
      <th>
        NO.
      </th>
      <th>
        Nama Customers
      </th>
      <th>
        Kategori
      </th>
      <th width="150">
        ACTION
      </th>
    </tr>
  </thead>
  <tbody>
  <?php
    
    include('koneksi.php');
    $query = mysql_query("SELECT * FROM customer ORDER BY customer ASC") or die(mysql_error());
    
    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{  
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
    <tr>
      <td>
        <?php echo $no; ?>
      </td>
      <td>
        <?php echo $data['customer'] ?>
      </td>
      <td>
        <?php if($data['kategori']==1){echo 'Small';}
                            elseif ($data['kategori']==2){echo 'Medium';}
                            elseif ($data['kategori']==3){echo 'Large';}
                            elseif ($data['kategori']==4){echo 'Small (Fasilitas)';}
                            elseif ($data['kategori']==5){echo 'Medium (Fasilitas)';} ?>
      </td>
      
      <td>
        <a href="edit-customer.php?id_customer=<?php echo $data['id_customer']; ?>" class="btn btn-success">Edit</a> | <a <a href="delete-customer.php?id_customer=<?php echo $data['id_customer'];?>" onclick="return confirm('Yakin Anda Ingin Menghapus Data ini ?')" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php $no++; } } ?>
 
    
  </tbody>
</table>
</div>
</div>



<div class="example-modal">
        <div class="modal modal-default add-slide">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Tambah Data Customer</h4>
              </div>
              <div class="modal-body">
                <p>


                  <div class="box box-info">
            
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" action="add-customer.php" class="form-horizontal" >
              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-4 control-label">Nama Customer</label>

                  <div class="col-sm-8">
                    <input type="text" class="form-control" name="customer" required>
                  </div>
                </div>
                <div class="form-group">
                     <label for="inputEmail3" class="col-sm-4 control-label">Kategori</label>
                     <div class="col-sm-8">
                        <select class="form-control" name="kategori" required>
                           <option value="" disabled="" selected="" style="display:none" ;="">Pilih</option>
                           <option value="1">Small</option>
                           <option value="2">Medium</option>
                           <option value="3">Large</option>
                           <option value="4">Small (Fasilitas)</option>
                           <option value="5">Medium (Fasilitas)</option>
                        </select>
                     </div>
                  </div>
                
                
              </div>
              <!-- /.box-body -->
              
              <!-- /.box-footer -->
            
          </div>

                </p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
              </div>
              </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
      </div>
      <script>
$(document).ready(function(){
    $('#customer ').DataTable();
});
</script>
<?php include_once("design/footer.php");?>