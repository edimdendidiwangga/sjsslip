<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->
<div class="row">
    <div class="col-md-12">
  <!-- TABLE: LATEST ORDERS -->
  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">Slip Gaji Terbaru</h3>
      <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div><!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
        <table class="table table-striped table-bordered table-responsive" id="example" >
          <thead>
            <tr>
              <th>No</th>
              <th>Tanggal Pembayaran</th>
              <th>Periode Salary</th>
              <th>Salary Yang Diterima</th>
              <th>Slip</th>
            </tr>
          </thead>
          <tbody>
          <?php
           $id_karyawan = $_SESSION['id_karyawan'];
    $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_karyawan = '$id_karyawan'
      ORDER BY slip_gaji.id_slip_gaji DESC limit 3") or die(mysql_error());
    
    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{ 
    
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
          <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data['tgl']; ?></td>
              <td><?php echo $data['periode_gaji']; ?></td>
              <td>Rp. <?php echo number_format($data['salary']); ?></td>
              <td><a target="_blank" href="slip-print.php?id_karyawan=<?php echo $data['id_karyawan'];?>&&kategori=<?php echo $data['kategori'];?>&&periode_gaji=<?php echo $data['periode_gaji'];?>" class="btn btn-success">View</a> | <a href="slip-aje.php?id_karyawan=<?php echo $data['id_karyawan'];?>&&kategori=<?php echo $data['kategori'];?>&&periode_gaji=<?php echo $data['periode_gaji'];?>" class="btn btn-danger">Download PDF</a></td>
            
            </tr>
           <?php $no++; }}?>
          </tbody>
        </table>
      </div><!-- /.table-responsive -->
    </div><!-- /.box-body -->
    <div class="box-footer clearfix">
     
    </div><!-- /.box-footer -->
  </div><!-- /.box -->
</div><!-- /.col -->
   
    </div><!-- /.col -->
</div><!-- /.row -->



<?php include_once("design/footer.php");?>