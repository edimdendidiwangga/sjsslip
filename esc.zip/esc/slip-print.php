
<?php include_once("koneksi.php");?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>ESC | PT SJS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style type="text/css">
    @media print {
  body * {
    visibility: hidden;
  }
  #section-to-print, #section-to-print * {
    visibility: visible;
  }
  #section-to-print {
    position: absolute;
    left: 0;
    top: 0;
  }
}
  </style>
</head>
<body id="editor">
<div class="wrapper">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12 page-header">
       
          <div class="col-sm-10"><img src="assets/dist/img/logo_sjs.jpg" class="img-responsive" width="100"></div><div class="col-sm-2">

          <h5 class="pull-right">Date: <?php echo date("d-m-Y");?></h5>
        
      </div>
      <!-- /.col -->
      
    </div>
    <!-- info row -->
    <h2 align="center"><b>SLIP GAJI</b></h2>
    <div class="alert alert-info>">
    <div class="row invoice-info">
      <div class="col-sm-6 invoice-col">
        <?php
           $id = $_GET['id_karyawan']; 
           $periode_gaji = $_GET['periode_gaji']; 
           $d = $_GET['kategori'];
     if($d==1){
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join small_income on pendapatan.id_kategori=small_income.id_small_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_karyawan = '$id' && slip_gaji.periode_gaji= '$periode_gaji'") or die(mysql_error());
    
    }else if ($d==2) {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join medium_income on pendapatan.id_kategori=medium_income.id_medium_income
      inner join medium_piece on pendapatan.id_kategori=medium_piece.id_medium_piece
      where slip_gaji.id_karyawan = '$id' && slip_gaji.periode_gaji= '$periode_gaji'") or die(mysql_error());
    }else if ($d==3) {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join large_income on pendapatan.id_kategori=large_income.id_large_income
      where slip_gaji.id_karyawan = '$id' && slip_gaji.periode_gaji= '$periode_gaji'") or die(mysql_error());
    }else if($d==4){
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join fasilitas on pendapatan.id_fasilitas=fasilitas.id_fasilitas
      inner join small_income on pendapatan.id_kategori=small_income.id_small_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_karyawan = '$id' && slip_gaji.periode_gaji= '$periode_gaji'") or die(mysql_error());
    }else if ($d==5) {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join fasilitas on pendapatan.id_fasilitas=fasilitas.id_fasilitas
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join medium_income on pendapatan.id_kategori=medium_income.id_medium_income
      inner join medium_piece on pendapatan.id_kategori=medium_piece.id_medium_piece
      where slip_gaji.id_karyawan = '$id' && slip_gaji.periode_gaji= '$periode_gaji'") or die(mysql_error());
    }

    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{ 
    
      $no = 1; 
      $data = mysql_fetch_assoc($query); ?>
        <table class="table bg-warning table-sm cf">
            <tr>
              <th style="width:40%">NAMA</th>
              
              <td>: <?php echo $data['nama_karyawan']; ?> </td>
            </tr>
            <tr>
              <th>JABATAN</th>
              <td>: <?php echo $data['jabatan']; ?> </td>
            </tr>
             <tr>
              <th>STATUS</th>
              
              <td>: <?php echo $data['status']; ?> </td>
            </tr>
            <tr>
              <th>NIK</th>
              
              <td>: <?php echo $data['nik']; ?></td>
            </tr>
             
            </table>
      </div>
      <!-- /.col -->
      
      
      <!-- /.col -->
      <div class="col-sm-6 invoice-col">
         <table class="table bg-warning cf">
            
            <tr>
              <th>PERUSAHAAN</th>
              
              <td>: <?php echo $data['customer']; ?> </td>
            </tr>
            <tr>
              <th>AREA / LOKASI</th>
              
              <td>: <?php echo $data['area']; ?> </td>
            </tr>
             <tr>
              <th>PERIODE</th>
              
              <td>: <?php echo $data['periode_gaji']; ?></td>
            </tr>
            </table>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
    </div>
    

    <!-- Table row -->
    <?php if($d==1||$d==2||$d==3){
      echo '<div class="col-sm-6">';
    }else{
      echo '<div class="col-sm-4">';
      }?>
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Pendapatan </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-hover table-responsive">
            <tr>
              <th style="width:50%">Gaji Pokok</th>
              <td>: Rp. </td>
              <td align="right"><?php echo number_format($data['gaji_pokok']); ?> </td>
            </tr>
            <tr>
             <?php if($d==1||$d==4){
                     if($data['id_customer']==1){
                      echo '<th>Service Charge</th>';
                     }else{
                      echo '<th>OT</th>';
                     }
                     
                  echo '<td>: Rp. </td>
                      <td align="right">'.number_format($data['service_charge']).' </td>
                      </tr>';
                }else if($d==2||$d==4){
                 echo '<tr>
                      <th>Rapel</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['rapel']).' </td>
                      </tr>
                      <tr>
                      <th>kehadiran</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['kehadiran']).' </td>
                      </tr>
                      <tr>
                      <th>Lembur</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['lembur']).' </td>
                      </tr>'
              ;}?>
              <tr>
            <th>Adjustment</th>
              <td>: Rp. </td>
              <td align="right"><?php echo number_format($data['adjustment']); ?> </td>
            </tr>
            <?php
            if($d==3){
                 echo '<tr>
                      <th>Rapel</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['rapel']).' </td>
                      </tr>
                      <tr>
                      <th>OverTime</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['overtime']).' </td>
                      </tr>
                      <tr>
                      <th>Shift Allowance</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['shift']).' </td>
                      </tr>
                      <tr>
                      <th>Kehadiran</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['kehadiran']).' </td>
                      </tr>
                      <th>Insentive</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['insentive']).' </td>
                      </tr>'
              ;}?>
            <tr>
              <th>Tunjangan Lain</th>
              <td>: Rp. </td>
              <td align="right"><?php echo number_format($data['tunjangan_lain']); ?> </td>
            </tr>
            
            <tr class="bg-info">
              <th>Grand Total Salary</th>
              <td>: Rp. </td>
              <td align="right"><?php echo number_format($data['total_pendapatan']); ?>  </td>
            </tr>
          </table>
            </div>
          </div>
          </div>
        
        <?php if($d==1||$d==2||$d==3){
      echo '<div class="col-sm-6">';
    }else{
      echo '<div class="col-sm-4">';
      }?>
        <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Potongan</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-hover table-responsive">
              <?php 
              if($d==1||$d==2||$d==3){
                echo'
              
            <tr>
              <th style="width:50%">PPH 21</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['pph21']).'</td>
            </tr>
            <tr>
              <th>Jamsostek (JHT 2%)</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['jamsostek']).'</td>
            </tr>
            <tr>
              <th>BPJS (1%)</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['bpjs']).'</td>
            </tr>
            <tr>
              <th>Pensiun (1%)</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['pensiun']).'</td>
            </tr>';
             if($d==2){
                 echo '<tr>
                      <th>Ketidakhadiran</th>
                      <td>: Rp. </td>
                      <td align="right"> '.number_format($data['tidak_hadir']).' </td>
                      </tr>'
              ;}
              }
            echo '
            <tr>
              <th>Potongan Lain</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['potongan_lain']).'</td>
            </tr>
            
            <tr class="bg-danger">
              <th>Total Potongan</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['total_potongan']).'</td>
            </tr>';
            ?>
          </table>
            </div>
          </div>
          </div>
          <?php
          if($d==4||$d==5){
          echo '<div class="col-sm-4">
        <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Fasiltas</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-hover table-responsive">
            <tr>
              <th style="width:50%">PPH 21</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['pph21_f']).'</td>
            </tr>
            <tr>
              <th>Jamsostek (JHT 2%)</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['jamsostek_f']).'</td>
            </tr>
            <tr>
              <th>BPJS (1%)</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['bpjs_f']).'</td>
            </tr>
            <tr>
              <th>Pensiun (1%)</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['pensiun_f']).'</td>
            </tr>
            
            
            <tr class="bg-success">
              <th>Total Fasilitas</th>
              <td>: Rp. </td>
              <td align="right">'.number_format($data['total_fasilitas']).'</td>
            </tr>
          </table>
            </div>
          </div>
          </div>';}
    ?>
    <!-- /.row -->

    <div class="row">
      <!-- accepted payments column -->
      
      <!-- /.col -->
     <div class="col-md-12">
      <div class="col-sm-6 invoice-col">
        <p class="lead"></p>

        <div class="table-responsive">
          <table class="table table-responsive">
            <tr class="bg-primary">
              <th style="width:50%">Salary Yang Diterima</th>
              <td>: Rp. </td>
              <td align="right"><b style="font-size: 16px;font-family: "Times New Roman", Georgia, Serif;"><?php echo number_format($data['salary']); ?></b></td>
            </tr>
          </table>
        </div>
      </div>
      <?php } ?>
      <!-- /.col -->
      </div>
    </div>
    <br>
    <p class="block" align="center"><i>PT SJS menyatakan cetakan ini sah sebagai bukti pembayaran yang sah.</p>
      <p class="block" align="center">Rincian Slip Pembayaran ini Dapat diakses di http://esc.sinarjernihsuksesindo.co.id</p>
      <p class="block" align="center">Untuk Informasi dapat menghubungi 021 - 8306679</i></p>
    <!-- /.row -->

  </section>
    </div><!-- /.col -->
</div><!-- /.row -->

<!-- ./wrapper -->
</body>
</html>
