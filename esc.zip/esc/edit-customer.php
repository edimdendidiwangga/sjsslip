<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
      <!-- Small boxes (Stat box) -->
      <div class="row">
<div class="row col-md-12">
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Form Edit Customer</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php 
													$id = $_GET['id_customer'];

													$query = mysql_query("
												        SELECT *
												        FROM customer
												        where customer.id_customer='$id'");
													
													$data = mysql_fetch_array($query);
													
													?>
       
            <form method="POST" enctype="multipart/form-data" action="update_customer.php" name="fupload">
              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-4 control-label">Nama Service</label>

                  <div class="col-sm-8">
                  <input type="hidden" name="id_customer" value="<?php echo $id; ?>" >
                    <input type="text" class="form-control" name="customer" value="<?php echo $data['customer']; ?>" required>
                  </div>
                </div>
                <br>
                <div class="form-group">
                     <label for="inputEmail3" class="col-sm-4 control-label">Kategori</label>
                     <div class="col-sm-8">
                        <select class="form-control" name="kategori" required>
                           <option value="<?php echo $data['kategori']; ?>">
                           <?php if($data['kategori']==1){echo 'Small';}
                            elseif ($data['kategori']==2){echo 'Medium';}
                            elseif ($data['kategori']==3){echo 'Large';}
                            elseif ($data['kategori']==4){echo 'Small (Fasilitas)';}
                            elseif ($data['kategori']==5){echo 'Medium (Fasilitas)';} ?></option>
                           <option value="1">Small</option>
                           <option value="2">Medium</option>
                           <option value="3">Large</option>
                           <option value="4">Small (Fasilitas)</option>
                           <option value="5">Medium (Fasilitas)</option>
                        </select>
                     </div>
                  </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <a href="customer.php"><button class="btn btn-default">Cancel</button></a>
                <button type="submit" class="btn btn-info pull-right">Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>


   </div>
   </div>
   </div>  
<?php include_once("design/footer.php");?>