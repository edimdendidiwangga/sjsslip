<?php 
include('koneksi.php');

$id = $_GET['id_customer'];

$query = mysql_query("delete from customer where id_customer='$id'") or die(mysql_error());

if ($query) {
	header('location:customer.php?message=delete');
}
?>