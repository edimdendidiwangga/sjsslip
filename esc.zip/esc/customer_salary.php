<?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->
<div class="row">
    <div class="col-md-12">
  <!-- TABLE: LATEST ORDERS -->
  <div class="box box-info">
    <div class="box-header with-border">
      <?php
    $id = $_GET['id_customer'];
      $query = mysql_query("SELECT * FROM customer where id_customer='$id'") or die(mysql_error());
      $d = mysql_fetch_assoc($query);
      ?>

      <h3 class="box-title">Slip Gaji Terbaru <?php echo strtoupper($d['customer'])?></h3>
      <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div><!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
        <table id="customer_salary" class="table table-striped table-bordered table-responsive">
          <thead>
            <tr>
              <th>NIK</th>
              <th>NAMA KARYAWAN</th>
              <th>GAJI POKOK</th>
              <?php if($d['kategori']==1||$d['kategori']==4){
                echo '<th>OT / SERVICE CHARGE</th>';}
                
              if($d['kategori']==2||$d['kategori']==5){
              echo "<th>RAPEL</th>
                    <th>KEHADIRAN</th>
                    <th>LEMBUR</th>";}?>
              <th>ADJUSTMENT</th>
              <?php if($d['kategori']==3){
              echo "<th>RAPEL</th>
                    <th>Overtime</th>
                    <th>Shift</th>
                    <th>kehadiran</th>
                    <th>Insentive</th>";}?>
              <th>TUNJANGAN LAIN</th>
              <th>TOTAL INCOME</th>
              <th>PPH21</th>
              <th>JAMSOSTEK</th>
              <th>BPJS</th>
              <th>PENSIUN</th>
              <?php if($d['kategori']==2||$d['kategori']==5){
              echo "<th>KETIDAKHADIRAN</th>";}?>
             
              <th>POTONGAN LAIN</th>
              <th>TOTAL POTONGAN</th>
              <th>THP</th>
              <?php if($d['kategori']==4||$d['kategori']==5){
              echo "<th class='bg-warning'>PPH21_F</th>
              <th class='bg-warning'>JAMSOSTEK_F</th>
              <th class='bg-warning'>BPJS_F</th>
              <th class='bg-warning'>PENSIUN_F</th>
              <th class='bg-warning'>Total Fasilitas</th>";}?>
              <th></th>
            </tr>
          </thead>
          <tbody>
           <?php
           $id = $_GET['id_customer'];
           $periode_gaji = $_GET['periode_gaji'];
           if($d['kategori']==1){
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join small_income on pendapatan.id_kategori=small_income.id_small_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_customer = '$id' && slip_gaji.periode_gaji = '$periode_gaji'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    
    }else if ($d['kategori']==2) {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join medium_income on pendapatan.id_kategori=medium_income.id_medium_income
      inner join medium_piece on pendapatan.id_kategori=medium_piece.id_medium_piece
      where slip_gaji.id_customer = '$id' && slip_gaji.periode_gaji = '$periode_gaji'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    }else if ($d['kategori']==3) {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join large_income on pendapatan.id_kategori=large_income.id_large_income
      where slip_gaji.id_customer = '$id' && slip_gaji.periode_gaji = '$periode_gaji'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    }else if($d['kategori']==4){
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join fasilitas on pendapatan.id_fasilitas=fasilitas.id_fasilitas
      inner join small_income on pendapatan.id_kategori=small_income.id_small_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_customer = '$id' && slip_gaji.periode_gaji = '$periode_gaji'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    }else if ($d['kategori']==5) {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join fasilitas on pendapatan.id_fasilitas=fasilitas.id_fasilitas
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join medium_income on pendapatan.id_kategori=medium_income.id_medium_income
      inner join medium_piece on pendapatan.id_kategori=medium_piece.id_medium_piece
      where slip_gaji.id_customer = '$id' && slip_gaji.periode_gaji = '$periode_gaji'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    }
    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{ 
    $sum=0;$sum6=0;$sum11=0;$sum16=0;$sum21=0;
    $sum2=0;$sum7=0;$sum12=0;$sum17=0;$sum22=0;
    $sum3=0; $sum8=0;$sum13=0;$sum18=0;$sum23=0;
    $sum4=0;$sum9=0;$sum14=0;$sum19=0;$sum24=0;
    $sum5=0;$sum10=0;$sum15=0;$sum20=0;$sum25=0;$sum26=0;
    
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
          <tr>
              <td><?php echo $data['nik']; ?></td>
              <td><?php echo $data['nama_karyawan']; ?></td>
              <td><?php echo number_format($data['gaji_pokok']); ?></td>
              <?php if($d['kategori']==1||$d['kategori']==4){
                echo '<td>'.number_format($data['service_charge']).'</td>';
              }else if($d['kategori']==2||$d['kategori']==5){
              echo '<td>'.number_format($data['rapel']).'</td>
                    <td>'.number_format($data['kehadiran']).'</td>
                    <td>'.number_format($data['lembur']).'</td>'
              ;}?>
              <td><?php echo number_format($data['adjustment']); ?></td>
              <?php if($d['kategori']==3){
                echo '<td>'.number_format($data['rapel']).'</td>
                      <td>'.number_format($data['overtime']).'</td>
                      <td>'.number_format($data['shift']).'</td>
                      <td>'.number_format($data['kehadiran']).'</td>
                      <td>'.number_format($data['insentive']).'</td>';}?>
              <td><?php echo number_format($data['tunjangan_lain']); ?></td>
              <td><?php echo number_format($data['total_pendapatan']); ?></td>
              <td><?php echo number_format($data['pph21']); ?></td>
              <td><?php echo number_format($data['jamsostek']); ?></td>
              <td><?php echo number_format($data['bpjs']); ?></td>
              <td><?php echo number_format($data['pensiun']); ?></td>
              <?php if($d['kategori']==2||$d['kategori']==5){
              echo '<td>'.number_format($data['tidak_hadir']).'</td>'
              ;}?>
              <td><?php echo number_format($data['potongan_lain']); ?></td>
              <td><?php echo number_format($data['total_potongan']); ?></td>
              <td><?php echo number_format($data['salary']); ?></td>
              <?php if($d['kategori']==4||$d['kategori']==5){
              echo '<td>'.number_format($data['pph21_f']).'</td>
                    <td>'.number_format($data['jamsostek_f']).'</td>
                    <td>'.number_format($data['bpjs_f']).'</td>
                    <td>'.number_format($data['pensiun_f']).'</td>
                    <td>'.number_format($data['total_fasilitas']).'</td>';}?>
              <td>
              
              <a href="slip-print.php?id_karyawan=<?php echo $data['id_karyawan']; ?>&&kategori=<?php echo $d['kategori'];?>&&periode_gaji=<?php echo $data['periode_gaji'];?>" class="btn btn-success">View</a> </td>
            </tr>
            <?php 
            $no++;
            $sum+=$data['gaji_pokok'];
            
            if($d['kategori']==1||$d['kategori']==4){
              $sum2+=$data['service_charge'];
            }else if($d['kategori']==2||$d['kategori']==5){
              $sum3+=$data['rapel'];
              $sum4+=$data['kehadiran'];
              $sum5+=$data['lembur'];
              }
            $sum16+=$data['adjustment'];
            if($d['kategori']==3){
              $sum22+=$data['rapel'];
              $sum23+=$data['overtime'];
              $sum24+=$data['shift'];
              $sum25+=$data['kehadiran'];
              $sum26+=$data['insentive'];
              }
            $sum6+=$data['tunjangan_lain'];
            $sum7+=$data['total_pendapatan'];
            $sum8+=$data['pph21']; 
            $sum9+=$data['jamsostek'];
            $sum10+=$data['bpjs'];
            $sum11+=$data['pensiun'];
            if($d['kategori']==2||$d['kategori']==5){
              $sum12+=$data['tidak_hadir'];
            }
            $sum13+=$data['potongan_lain']; 
            $sum14+=$data['total_potongan'];
            $sum15+=$data['salary']; 
            if($d['kategori']==4||$d['kategori']==5){
              $sum17+=$data['pph21_f'];
              $sum18+=$data['jamsostek_f'];
              $sum19+=$data['bpjs_f'];
              $sum20+=$data['pensiun_f'];
              $sum21+=$data['total_fasilitas'];
            }
            } } ?>
            
          </tbody>
          <tfoot class="bg-info">
            <th colspan="2">TOTAL</th>
              <th><?php echo number_format($sum); ?></th>
              <?php if($d['kategori']==1 || $d['kategori']==4){
                echo '<th>'.number_format($sum2).'</th>';
              }
              if($d['kategori']==2 || $d['kategori']==5){
              echo '<th>'.number_format($sum3).'</th>
                    <th>'.number_format($sum4).'</th>
                    <th>'.number_format($sum5).'</th>'
              ;}?>
              <th><?php echo number_format($sum16); ?></th>
              <?php if($d['kategori']==3){
              echo '<th>'.number_format($sum22).'</th>
                    <th>'.number_format($sum23).'</th>
                    <th>'.number_format($sum24).'</th>
                    <th>'.number_format($sum25).'</th>
                    <th>'.number_format($sum26).'</th>'
              ;}?>
              <th><?php echo number_format($sum6); ?></th>
              <th><?php echo number_format($sum7); ?></th>
              <th><?php echo number_format($sum8); ?></th>
              <th><?php echo number_format($sum9); ?></th>
              <th><?php echo number_format($sum10); ?></th>
              <th><?php echo number_format($sum11); ?></th>
              <?php if($d['kategori']==2||$d['kategori']==5){
                echo '<th>'.number_format($sum12).'</th>';
              }?>
              <th><?php echo number_format($sum13); ?></th>
              <th><?php echo number_format($sum14); ?></th>
              <th><?php echo number_format($sum15); ?></th>
              <?php if($d['kategori']==4||$d['kategori']==5){
                echo '<th class="bg-warning">'.number_format($sum17).'</th>';
                 echo '<th class="bg-warning">'.number_format($sum18).'</th>';
                  echo '<th class="bg-warning">'.number_format($sum19).'</th>';
                   echo '<th class="bg-warning">'.number_format($sum20).'</th>';
                    echo '<th class="bg-warning">'.number_format($sum21).'</th>';
              }?>
              <th><a href="export-salary.php?id_customer=<?php echo $id; ?>&kategori=<?php echo $d['kategori'];?>" class="btn btn-primary">Export</a></th>
          </tfoot>
        </table>
      </div><!-- /.table-responsive -->
    </div><!-- /.box-body -->
    <div class="box-footer clearfix">
     
    </div><!-- /.box-footer -->
  </div><!-- /.box -->
</div><!-- /.col -->
   
    </div><!-- /.col -->
</div><!-- /.row -->
<script>
$(document).ready(function(){
    $('#customer_salary ').DataTable();
});
</script>
<?php include_once("design/footer.php");?>