 <?php include_once("cek-login.php");?>
<?php include_once("koneksi.php");?>
<?php include_once("design/header.php");?>
<!-- Main row -->

<?php
//koneksi ke database, username,password  dan namadatabase menyesuaikan 
mysql_connect('localhost', 'root', '');
mysql_select_db('db_slip_gaji');

//memanggil file excel_reader
require "excel_reader.php";

//jika tombol import ditekan
if(isset($_POST['submit'])){
  
    $id_customer = $_POST['id_customer'];
    $periode_gaji = $_POST['periode'];
    $tgl = date("d-m-Y");

    
     $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $count = mb_strlen($chars);

    for ($i = 0, $result = ''; $i < 6; $i++) {
        $index = rand(0, $count - 1);
        $result .= mb_substr($chars, $index, 1);
    }

     $password = $result;
     
    

    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    chmod($_FILES['filepegawaiall']['name'],0777);
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);

//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    { 
//       membaca data (kolom ke-1 sd terakhir)
      $nik            = $data->val($i, 1, 0);
      $nama_karyawan  = $data->val($i, 2, 0);
      $jabatan        = $data->val($i, 3, 0);
      $status         = $data->val($i, 4, 0);
      $area           = $data->val($i, 5, 0);
      $gaji_pokok     = $data->val($i, 6, 0);
      $tunjangan_lain = $data->val($i, 7, 0);
      $total_pendapatan  = $data->val($i, 8, 0);
      $pph21             = $data->val($i, 9, 0);
      $jamsostek         = $data->val($i, 10, 0);
      $bpjs              = $data->val($i, 11, 0);
      $pensiun           = $data->val($i, 12, 0);
      $potongan_lain     = $data->val($i, 13, 0);
      $total_potongan    = $data->val($i, 14, 0);
      $salary            = $data->val($i, 15, 0);
      $service_charge    = $data->val($i, 16, 0);

     
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
     $sql = "select * from karyawan where nik='$nik'";
    $check = mysql_query($sql);
    $checkrows=mysql_num_rows($check);


    if($checkrows>0) {
       
     
      $query = mysql_query("insert into pendapatan (id_pendapatan, gaji_pokok, tunjangan_lain, service_charge, total_pendapatan) 
  values('', '$gaji_pokok', '$tunjangan_lain', '$service_charge', '$total_pendapatan')") or die(mysql_error());

 $query = mysql_query("insert into potongan (id_potongan, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
  values('', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());

$sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
 $hasil = mysql_query($sql);
 $row = mysql_fetch_array($hasil);
 $last_id_pendapatan = $row['last_id_pendapatan'];

 //simpan data ke database

$sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
 $hasil = mysql_query($sql);
 $row = mysql_fetch_array($hasil);
 $last_id_potongan = $row['last_id_potongan'];
 
 $sql = "select id_karyawan, nik from karyawan where nik='$nik'";
 $hasil = mysql_query($sql);
 $row = mysql_fetch_array($hasil);
 $last_id_karyawan = $row['id_karyawan'];

$query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
  values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());    
   } else {
 $query = "INSERT into karyawan (id_karyawan, nik, nama_karyawan, jabatan, status, area) 
        values('', '$nik', '$nama_karyawan', '$jabatan', '$status', '$area')";
        $hasil = mysql_query($query);

    $query = mysql_query("insert into pendapatan (id_pendapatan, gaji_pokok, tunjangan_lain, service_charge, total_pendapatan) 
      values('', '$gaji_pokok', '$tunjangan_lain', '$service_charge', '$total_pendapatan')") or die(mysql_error());

 $query = mysql_query("insert into potongan (id_potongan, pph21, jamsostek, bpjs, pensiun, potongan_lain, total_potongan) 
  values('', '$pph21', '$jamsostek', '$bpjs', '$pensiun', '$potongan_lain', '$total_potongan' )") or die(mysql_error());

$sql = "select max(id_karyawan) as last_id_karyawan from karyawan limit 1";
 $hasil = mysql_query($sql);
 $row = mysql_fetch_array($hasil);
 $last_id_karyawan = $row['last_id_karyawan'];

$sql = "select max(id_pendapatan) as last_id_pendapatan from pendapatan limit 1";
 $hasil = mysql_query($sql);
 $row = mysql_fetch_array($hasil);
 $last_id_pendapatan = $row['last_id_pendapatan'];


$sql = "select max(id_potongan) as last_id_potongan from potongan limit 1";
 $hasil = mysql_query($sql);
 $row = mysql_fetch_array($hasil);
 $last_id_potongan = $row['last_id_potongan'];
 
$query = mysql_query("insert into slip_gaji (id_slip_gaji, id_karyawan, id_customer, id_pendapatan, id_potongan, salary, tgl, periode_gaji) 
  values('', '$last_id_karyawan', '$id_customer', '$last_id_pendapatan', '$last_id_potongan', '$salary', '$tgl', '$periode_gaji')") or die(mysql_error());

$query = mysql_query("insert into users (id_users, id_karyawan, password, level) 
  values('', '$last_id_karyawan', '$password', '1')") or die(mysql_error());
 
}
}
    if(!$hasil){
//          jika import gagal
          die(mysql_error());
      }else{
//          jika impor berhasil
          echo "<script>
    alert('DATA BERHASIL di IMPORT!');
    window.location='salary.php';
    </script>";
    }
    
//    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
}

?>



<div class="row">
    <div class="col-md-12">
  <!-- TABLE: LATEST ORDERS -->
  <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">List Salary per Customer</h3>
      <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
      </div>
    </div><!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
      <a class="btn btn-warning" data-target=".add-import" data-toggle="modal"><i class="fa fa-download"></i> Import</a> 
        <table id="example1" class="table table-bordered table-striped table-hover table-responsive">
  <thead>
    <tr>
      <th>
        NO.
      </th>
      <th>
        Nama Customers
      </th>
      <th>
      Periode
      </th>
      <th class="text-center">
        Total Salary Terbaru
      </th>
      <th width="220">
        ACTION
      </th>
    </tr>
  </thead>
  <tbody>
  <?php
    include('koneksi.php');
    
    $query = mysql_query("SELECT SUM(slip_gaji.salary) as total, slip_gaji.periode_gaji, slip_gaji.id_customer FROM slip_gaji inner join customer WHERE slip_gaji.id_customer=customer.id_customer 
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());

    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{  
      $no = 1; 
      $sum=0;
      while($data = mysql_fetch_assoc($query)){ ?>
     
      <tr>
      <td>
        <?php echo $no; ?>
      </td>
      <td>
        <?php echo $data['id_customer']; ?>
      </td>
      <td>
        <?php echo $data['periode_gaji']; ?>
      </td>
      
      <td align="center">
        <?php echo number_format($data['total']); ?>
      </td>
      <td>
        <a class="btn btn-primary" href="salary_karyawan.php?id_customer=<?php echo $data['id_customer']; ?>">View</a>
      </td>
      </tr>
    <?php $no++; $sum+=$data['total']; } } 
    
    ?>
 
  </tbody>
  <tfoot class="bg-info">
            <th colspan="3">TOTAL</th>
            <th class="text-center"><?php echo number_format($sum); ?></th>
            <th></th>
          </tfoot>
</table>
      </div><!-- /.table-responsive -->
    </div><!-- /.box-body -->
    <div class="box-footer clearfix">
     
    </div><!-- /.box-footer -->
  </div><!-- /.box -->
</div><!-- /.col -->
   




    </div><!-- /.col -->
</div><!-- /.row -->



<div class="example-modal">
    <div class="modal modal-default add-import">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                    <h4 class="modal-title">Tambah Data Customer</h4>
                </div>
                <div class="modal-body">
                            <form class="form-control" name="myForm" id="myForm" onSubmit="return validateForm()" action="salary.php" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                    <label class="col-sm-4 control-label">Nama Customer</label>
                                       
                                        <div class="col-sm-8">
                                            <select name="id_customer" class="form-control" required>
                                             <option value="" disabled="" selected="" style="display:none" ;="">Pilih</option>
                                             <?php
                                            $query = mysql_query("SELECT * FROM customer ORDER BY customer ASC") or die(mysql_error());
                              
                                            if(mysql_num_rows($query) == 0){ 
                                
                                             echo '<option value="">Tidak ada data!</option>';
                                
                                            }else{  
                                            
                                            while($data = mysql_fetch_assoc($query)){ ?>
                                                         <option value="<?php echo $data['id_customer']; ?>"><?php echo $data['customer']; ?></option>
                                            <?php }} ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-4 control-label">Kategori</label>

                                        <div class="col-sm-8">
                                            <select class="form-control" name="kategori" required>
                                            <option value="" disabled="" selected="" style="display:none" ;="">Pilih</option>
                                              <option value="1">Small</option>
                                              <option value="2">Medium</option>
                                              <option value="3">Large</option>
                                             
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="form-group">
                                    <label class="col-sm-4 control-label">Periode Pengajian</label>
                                        <div class="col-sm-8">
                                    <input type="text" name="periode" class="form-control" data-provide="datepicker" id="datepicker" placeholder="Month Year">
                                  </div>
                                  </div>
                                  
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Upload Excel</label>
                                        <div class="col-sm-8">
                                            <input type="file" id="filepegawaiall" name="filepegawaiall" class="form-control" required />
                                            <br>
                                            <p>File Harus Berekstensi .xls (97-2003).</p>
                                        </div>
                                    </div>
                     </div>

                    
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger pull-left">Reset</button>
                    <button type="submit" name="submit" class="btn btn-primary">Save</button>
                </div>
                </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->


      </div>
</div>
<!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
  
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateForm()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }

        if(!hasExtension('filepegawaiall', ['.xls'])){
            alert("Hanya file XLS (Excel 2003) yang diijinkan.");
            return false;
        }
    }
</script>
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": false,
      "autoWidth": false
    });
  });
</script>

<?php include_once("design/footer.php");?>