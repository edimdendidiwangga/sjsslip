<?php include_once("koneksi.php");?>
<?php


header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=slip_gaji.xls");
?>
<?php
$id = $_GET['id_customer'];
$d = $_GET['kategori'];
      if($d=='1'){
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join small_income on pendapatan.id_kategori=small_income.id_small_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_customer = '$id'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    
    }elseif ($d=='2') {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join medium_income on pendapatan.id_kategori=medium_income.id_medium_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join medium_piece on pendapatan.id_kategori=medium_piece.id_medium_piece
      where slip_gaji.id_customer = '$id'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    }
?>
<table id="customer_salary" class="table table-striped table-bordered table-responsive">
          <thead>
            <tr>
              <th>NIK</th>
              <th>NAMA KARYAWAN</th>
              <th>JABATAN</th>
              <th>STATUS</th>
              <th>AREA</th>
              <th>GAJI POKOK</th>
              <?php if($d=='1'){
                echo '
              <th>SERVICE CHARGE</th>
            ';}else if($d=='2'){
              echo "<th>RAPEL</th>
                    <th>KEHADIRAN</th>
                    <th>LEMBUR</th>";}?>
              <th>ADJUSTMENT</th>
              <th>TUNJANGAN LAIN</th>
              <th>TOTAL INCOME</th>
              <th>PPH21</th>
              <th>JAMSOSTEK</th>
              <th>BPJS</th>
              <th>PENSIUN</th>
              <?php if($d=='2'){
              echo "<th>KETIDAKHADIRAN</th>";}?>
              <th>POTONGAN LAIN</th>
              <th>TOTAL POTONGAN</th>
              <th>THP</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
           <?php
           $id = $_GET['id_customer'];
           if($d=='1'){
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join small_income on pendapatan.id_kategori=small_income.id_small_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      where slip_gaji.id_customer = '$id'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    
    }elseif ($d=='2') {
      $query = mysql_query("SELECT * FROM slip_gaji 
      inner join karyawan on slip_gaji.id_karyawan=karyawan.id_karyawan
      inner join customer on slip_gaji.id_customer=customer.id_customer
      inner join pendapatan on slip_gaji.id_pendapatan=pendapatan.id_pendapatan
      inner join medium_income on pendapatan.id_kategori=medium_income.id_medium_income
      inner join potongan on slip_gaji.id_potongan=potongan.id_potongan
      inner join medium_piece on pendapatan.id_kategori=medium_piece.id_medium_piece
      where slip_gaji.id_customer = '$id'
      ORDER BY slip_gaji.id_slip_gaji DESC") or die(mysql_error());
    }

    if(mysql_num_rows($query) == 0){ 
      
      echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
      
    }else{ 
    $sum=0;$sum6=0;$sum11=0;
    $sum2=0;$sum7=0;$sum12=0;
    $sum3=0; $sum8=0;$sum13=0;
    $sum4=0;$sum9=0;$sum14=0;
    $sum5=0;$sum10=0;$sum15=0;$sum16=0;
    
      $no = 1; 
      while($data = mysql_fetch_assoc($query)){ ?>
          <tr>
              <td><?php echo $data['nik']; ?></td>
              <td><?php echo $data['nama_karyawan']; ?></td>
              <td><?php echo $data['jabatan']; ?></td>
              <td><?php echo $data['status']; ?></td>
              <td><?php echo $data['area']; ?></td>
              <td><?php echo $data['gaji_pokok']; ?></td>
              <?php if($d==1){
                echo '<td>'.$data['service_charge'].'</td>';
              }else if($d==2){
              echo '<td>'.$data['rapel'].'</td>
                    <td>'.$data['kehadiran'].'</td>
                    <td>'.$data['lembur'].'</td>'
              ;}?>
              <td><?php echo $data['adjustment']; ?></td>
              <td><?php echo $data['tunjangan_lain']; ?></td>
              <td><?php echo $data['total_pendapatan']; ?></td>
              <td><?php echo $data['pph21']; ?></td>
              <td><?php echo $data['jamsostek']; ?></td>
              <td><?php echo $data['bpjs']; ?></td>
              <td><?php echo $data['pensiun']; ?></td>
              <?php if($d==2){
              echo '<td>'.$data['tidak_hadir'].'</td>'
              ;}?>
              <td><?php echo $data['potongan_lain']; ?></td>
              <td><?php echo $data['total_potongan']; ?></td>
              <td><?php echo $data['salary']; ?></td>
              
            </tr>
            <?php 
            $no++;
            $sum+=$data['gaji_pokok'];
            
            if($d==1){
              $sum2+=$data['service_charge'];
            }else if($d==2){
              $sum3+=$data['rapel'];
              $sum4+=$data['kehadiran'];
              $sum5+=$data['lembur'];
              }
            $sum16+=$data['adjustment'];
            $sum6+=$data['tunjangan_lain'];
            $sum7+=$data['total_pendapatan'];
            $sum8+=$data['pph21']; 
            $sum9+=$data['jamsostek'];
            $sum10+=$data['bpjs'];
            $sum11+=$data['pensiun'];
            if($d==2){
              $sum12+=$data['tidak_hadir'];
            }
            $sum13+=$data['potongan_lain']; 
            $sum14+=$data['total_potongan'];
            $sum15+=$data['salary']; } } ?>
            
          </tbody>
          <tfoot class="bg-info">
            <th colspan="2">TOTAL</th>
              
              <th><?php echo $sum; ?></th>
              <?php if($d==1){
                echo '<th>'.$sum2.'</th>';
              }else if($d==2){
              echo '<th>'.$sum3.'</th>
                    <th>'.$sum4.'</th>
                    <th>'.$sum5.'</th>'
              ;}?>
              <th><?php echo $sum16; ?></th>
              <th><?php echo $sum6; ?></th>
              <th><?php echo $sum7; ?></th>
              <th><?php echo $sum8; ?></th>
              <th><?php echo $sum9; ?></th>
              <th><?php echo $sum10; ?></th>
              <th><?php echo $sum11; ?></th>
              <?php if($d==2){
                echo '<th>'.$sum12.'</th>';
              }?>
              <th><?php echo $sum13; ?></th>
              <th><?php echo $sum14; ?></th>
              <th><?php echo $sum15; ?></th>
              
          </tfoot>
        </table>
